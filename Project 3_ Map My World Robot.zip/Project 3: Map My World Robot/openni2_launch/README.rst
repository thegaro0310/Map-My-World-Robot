**Repository for openni2_launch is moved to https://github.com/ros-drivers/openni2_camera**

See detail at https://github.com/ros-drivers/openni2_camera/pull/55 if necessary.
